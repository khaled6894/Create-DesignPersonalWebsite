function showInfo() {
const extraBox = document.getElementById("extra-info");
extraBox.style.display = "flex";
}